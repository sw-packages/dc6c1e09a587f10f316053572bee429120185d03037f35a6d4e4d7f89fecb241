/* $OpenBSD: o_init.c,v 1.8 2014/06/12 15:49:27 deraadt Exp $ */
/* Ted Unangst places this file in the public domain. */

#include <openssl/crypto.h>

void
OPENSSL_init(void)
{

}
